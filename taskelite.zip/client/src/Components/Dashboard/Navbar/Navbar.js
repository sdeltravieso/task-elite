import React from "react";
import "./Navbar.css";

const Navbar = (props) => (
    <div className="navbarStyle">
        <h1>Task Elite</h1>
        
    
    </div>

)

export default Navbar;